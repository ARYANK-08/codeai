import requests
from django.shortcuts import render

import google.generativeai as genai
from django.shortcuts import render, redirect
from .forms import HtmlCodeForm, CodeRequestForm
import google.generativeai as genai

# Configure the API
genai.configure(api_key="AIzaSyCWxLcSHWh_ccrE15Gyo0t_8WhPfAXXelM")

def fetch_gemini_code(description):
    generation_config = {
        "temperature": 0.9,
        "top_p": 1,
        "top_k": 1,
        "max_output_tokens": 2048,
    }

    safety_settings = [
        {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
        {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
        {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
        {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
    ]

    model = genai.GenerativeModel(model_name="gemini-1.0-pro",
                                  generation_config=generation_config,
                                  safety_settings=safety_settings)
    convo = model.start_chat(history=[])
    convo.send_message(description)
    return convo.last.text

from django.shortcuts import render
from .forms import CodeRequestForm

from django.shortcuts import render
from .forms import CodeRequestForm
def code_runner(request):
    generated_code = None
    if request.method == 'POST':
        form = CodeRequestForm(request.POST)
        if form.is_valid():
            description = form.cleaned_data['code_description']
            if 'generate' in request.POST:
                html = """
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<style>
    canvas {
        border:1px solid #d3d3d3;
        background-color: #f1f1f1;
    }
    .bottom-container {
        text-align: center;
        margin-top: 20px;
    }
    .bottom-container button {
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
    }
</style>
</head>
<body onload="startGame()">
<div class="bottom-container">
    <button onmousedown="accelerate(-0.2)" onmouseup="accelerate(0.05)">ACCELERATE</button>
    <p>Use the ACCELERATE button to stay in the air</p>
    <p>How long can you stay alive?</p>
</div>
<canvas></canvas>
<script>
var myGamePiece;
var myObstacles = [];
var myScore;

function startGame() {
    myGamePiece = new component(30, 30, "red", 10, 120);
    myGamePiece.gravity = 0.05;
    myScore = new component("30px", "Consolas", "black", 280, 40, "text");
    myGameArea.start();
}

var myGameArea = {
    canvas : document.querySelector("canvas"),
    start : function() {
        this.canvas.width = 480;
        this.canvas.height = 270;
        this.context = this.canvas.getContext("2d");
        this.frameNo = 0;
        this.interval = setInterval(updateGameArea, 20);
    },
    clear : function() {
        this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
}

function component(width, height, color, x, y, type) {
    this.type = type;
    this.score = 0;
    this.width = width;
    this.height = height;
    this.speedX = 0;
    this.speedY = 0;    
    this.x = x;
    this.y = y;
    this.gravity = 0;
    this.gravitySpeed = 0;
    this.update = function() {
        ctx = myGameArea.context;
        if (this.type == "text") {
            ctx.font = this.width + " " + this.height;
            ctx.fillStyle = color;
            ctx.fillText(this.text, this.x, this.y);
        } else {
            ctx.fillStyle = color;
            ctx.fillRect(this.x, this.y, this.width, this.height);
        }
    }
    this.newPos = function() {
        this.gravitySpeed += this.gravity;
        this.x += this.speedX;
        this.y += this.speedY + this.gravitySpeed;
        this.hitBottom();
    }
    this.hitBottom = function() {
        var rockbottom = myGameArea.canvas.height - this.height;
        if (this.y > rockbottom) {
            this.y = rockbottom;
            this.gravitySpeed = 0;
        }
    }
    this.crashWith = function(otherobj) {
        var myleft = this.x;
        var myright = this.x + (this.width);
        var mytop = this.y;
        var mybottom = this.y + (this.height);
        var otherleft = otherobj.x;
        var otherright = otherobj.x + (otherobj.width);
        var othertop = otherobj.y;
        var otherbottom = otherobj.y + (otherobj.height);
        var crash = true;
        if ((mybottom < othertop) || (mytop > otherbottom) || (myright < otherleft) || (myleft > otherright)) {
            crash = false;
        }
        return crash;
    }
}

function updateGameArea() {
    var x, height, gap, minHeight, maxHeight, minGap, maxGap;
    for (i = 0; i < myObstacles.length; i += 1) {
        if (myGamePiece.crashWith(myObstacles[i])) {
            return;
        } 
    }
    myGameArea.clear();
    myGameArea.frameNo += 1;
    if (myGameArea.frameNo == 1 || everyinterval(150)) {
        x = myGameArea.canvas.width;
        minHeight = 20;
        maxHeight = 200;
        height = Math.floor(Math.random()*(maxHeight-minHeight+1)+minHeight);
        minGap = 50;
        maxGap = 200;
        gap = Math.floor(Math.random()*(maxGap-minGap+1)+minGap);
        myObstacles.push(new component(10, height, "green", x, 0));
        myObstacles.push(new component(10, x - height - gap, "green", x, height + gap));
    }
    for (i = 0; i < myObstacles.length; i += 1) {
        myObstacles[i].x += -1;
        myObstacles[i].update();
    }
    myScore.text="SCORE: " + myGameArea.frameNo;
    myScore.update();
    myGamePiece.newPos();
    myGamePiece.update();
}

function everyinterval(n) {
    if ((myGameArea.frameNo / n) % 1 == 0) {return true;}
    return false;
}

function accelerate(n) {
    myGamePiece.gravity = n;
}
</script>
</body>
</html>

"""
                generated_code = fetch_gemini_code(f"{description} ")
                generated_code = clean_html_code(generated_code)  # Clean the code
            elif 'run' in request.POST:
                generated_code = form.cleaned_data['code_output']
                generated_code = clean_html_code(generated_code)  # Clean the code

            form = CodeRequestForm(initial={
                'code_description': description,
                'code_output': generated_code
            })
    else:
        form = CodeRequestForm()

    return render(request, 'sherwinai/code_runner.html', {
        'form': form,
        'generated_code': generated_code
    })
import re

import re

def clean_html_code(html_code):
    # Replace ```css with <style> tag
    html_code = re.sub(r'```css\s*([\s\S]*?)```', r'<style>\1</style>', html_code)
    
    # Replace ```js with <script> tag
    html_code = re.sub(r'```js\s*([\s\S]*?)```', r'<script>\1</script>', html_code)
    
    # Remove HTML comments
    html_code = re.sub(r'<!--.*?-->', '', html_code, flags=re.DOTALL)
    

    return html_code










# OG RUNNING 
# def code_runner(request):
#     generated_code = ''  # Initialize generated_code to an empty string

#     if request.method == 'POST':
#         form = CodeRequestForm(request.POST)
#         if form.is_valid():
#             description = form.cleaned_data['code_description']
#             # Assuming fetch_gemini_code is a function that generates code based on description
#             generated_code = fetch_gemini_code(description)
#     else:
#         form = CodeRequestForm()

#     return render(request, 'sherwinai/code_runner.html', {
#         'form': form,
#         'generated_code': generated_code
#     })

















# from django.shortcuts import render

# # Create your views here.
# """
# At the command line, only need to run once to install the package via pip:

# $ pip install google-generativeai
# """

# import google.generativeai as genai

# genai.configure(api_key="YOUR_API_KEY")

# # Set up the model
# generation_config = {
#   "temperature": 0.9,
#   "top_p": 1,
#   "top_k": 1,
#   "max_output_tokens": 2048,
# }

# safety_settings = [
#   {
#     "category": "HARM_CATEGORY_HARASSMENT",
#     "threshold": "BLOCK_MEDIUM_AND_ABOVE"
#   },
#   {
#     "category": "HARM_CATEGORY_HATE_SPEECH",
#     "threshold": "BLOCK_MEDIUM_AND_ABOVE"
#   },
#   {
#     "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
#     "threshold": "BLOCK_MEDIUM_AND_ABOVE"
#   },
#   {
#     "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
#     "threshold": "BLOCK_MEDIUM_AND_ABOVE"
#   },
# ]

# model = genai.GenerativeModel(model_name="gemini-1.0-pro",
#                               generation_config=generation_config,
#                               safety_settings=safety_settings)

# convo = model.start_chat(history=[
# ])

# convo.send_message("YOUR_USER_INPUT")
# print(convo.last.text)


import sys
from io import StringIO
from django.shortcuts import render
from django.views import View
from .forms import CodeForm

class RunCodeView(View):
    form_class = CodeForm
    template_name = 'sherwinai/execute_code.html'

    def get(self, request):
        form = self.form_class()
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        form = self.form_class(request.POST)
        if form.is_valid():
            code = form.cleaned_data['code']
            # Capture output
            old_stdout = sys.stdout
            redirected_output = sys.stdout = StringIO()
            try:
                exec(code)
            except Exception as e:
                output = str(e)
            else:
                sys.stdout.seek(0)
                output = redirected_output.read()
            finally:
                sys.stdout = old_stdout
            return render(request, self.template_name, {'form': form, 'output': output})
        return render(request, self.template_name, {'form': form})

# from django.shortcuts import render
# from .forms import HtmlCodeForm

# def code_runner(request):
#     html_code = ''
#     css_code = ''
#     js_code = ''
    
#     if request.method == 'POST':
#         form = HtmlCodeForm(request.POST)
#         if form.is_valid():
#             html_code = form.cleaned_data['html_code']
#             css_code = form.cleaned_data['css_code']
#             js_code = form.cleaned_data['js_code']
#     else:
#         form = HtmlCodeForm()

#     return render(request, 'sherwinai/code_runner.html', {
#         'form': form,
#         'html_code': html_code,
#         'css_code': css_code,
#         'js_code': js_code
#     })

