from django.apps import AppConfig


class SherwinaiConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "sherwinai"
