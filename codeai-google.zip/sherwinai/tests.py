# from django.test import TestCase

# # Create your tests here.
# code_to_execute = """
# def greet(name):
#     print(f"Hello, {name}!")

# greet("Alice")
# """

# try:
#     exec(code_to_execute)
# except Exception as e:
#     print("An error occurred:", e)

import requests
from django.shortcuts import render

import google.generativeai as genai
from django.shortcuts import render, redirect
from .forms import HtmlCodeForm, CodeRequestForm
import google.generativeai as genai

# Configure the API
genai.configure(api_key="AIzaSyCWxLcSHWh_ccrE15Gyo0t_8WhPfAXXelM")

def fetch_gemini_code(description):
    generation_config = {
        "temperature": 0.9,
        "top_p": 1,
        "top_k": 1,
        "max_output_tokens": 2048,
    }

    safety_settings = [
        {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
        {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
        {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
        {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
    ]

    model = genai.GenerativeModel(model_name="gemini-1.0-pro",
                                  generation_config=generation_config,
                                  safety_settings=safety_settings)
    convo = model.start_chat(history=[])
    convo.send_message(description)
    return convo.last.text

from django.shortcuts import render
from .forms import CodeRequestForm


def code_runner(request):
    generated_code = ''  # Initialize generated_code to an empty string

    if request.method == 'POST':
        form = CodeRequestForm(request.POST)
        if form.is_valid():
            description = form.cleaned_data['code_description']
            generated_code = fetch_gemini_code(description)
    else:
        form = CodeRequestForm()

    return render(request, 'sherwinai/code_runner.html', {
        'form': form,
        'generated_code': generated_code
    })

<!-- 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Code Runner</title>
    <style>
        {{ css_code|safe }}
    </style>
</head>
<body>
    <h1>Enter HTML, CSS, and JavaScript</h1>
    <form method="post">
        {% csrf_token %}
        {{ form.as_p }}
        <button type="submit">Run</button>
    </form>
    
    <div id="output">
        {{ html_code|safe }}
        <script>
            {{ js_code|safe }}
        </script>
    </div>
</body>
</html> -->

